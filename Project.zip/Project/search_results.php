<?php
session_start();
require_once 'db.php';
require_once 'includes/search.php';
$query = input_text($_GET, 'q');
if ($query === '') { header('Location: index.php'); exit; }
$query = mb_substr($query, 0, 255);
$filters = search_filters($_GET);
$products = [];
$search_error = '';
try {
    $products = search_products($query, $filters, 200, microtime(true) + 1.8);
    log_search($query, false, count($products));
} catch (Throwable $exception) {
    $search_error = 'Search is temporarily unavailable. Please try again.';
    error_log('Keyword search: ' . $exception->getMessage());
}
db_run('SET SESSION max_statement_time = ?', 'd', [0]);
$categories = db_run('SELECT category_id, category_name FROM categories WHERE is_active = 1 ORDER BY category_name')->get_result();
$brands = db_run("SELECT DISTINCT brand FROM products WHERE status = 'active' AND brand IS NOT NULL AND brand <> '' ORDER BY brand")->get_result();
$spec_keys = db_run('SELECT DISTINCT spec_key FROM product_specs ORDER BY spec_key')->get_result();
$page_title = 'Search Results';
include 'includes/header.php';
?>
<h1>Showing results for: <?= h($query) ?></h1>
<p class="muted">Keyword results · <?= count($products) ?> products<?= count($products) === 200 ? ' (showing the first 200; refine your filters)' : '' ?></p>
<div class="category-layout">
<aside class="filters"><h2>Filters</h2><form method="GET" action="search_results.php">
    <input type="hidden" name="q" value="<?= h($query) ?>">
    <div class="filter-group"><label for="cat">Category</label><select id="cat" name="cat"><option value="">All Categories</option>
    <?php while ($category = $categories->fetch_assoc()): ?><option value="<?= (int) $category['category_id'] ?>" <?= $filters['cat'] === (int) $category['category_id'] ? 'selected' : '' ?>><?= h($category['category_name']) ?></option><?php endwhile; ?>
    </select></div>
    <div class="filter-group"><label>Price Range (৳)</label><div class="price-inputs"><input aria-label="Minimum price" name="min_price" type="number" min="0" step="0.01" placeholder="Min" value="<?= h($filters['min_price']) ?>"><input aria-label="Maximum price" name="max_price" type="number" min="0" step="0.01" placeholder="Max" value="<?= h($filters['max_price']) ?>"></div></div>
    <div class="filter-group"><label for="brand">Brand</label><select id="brand" name="brand"><option value="">All Brands</option><?php while ($brand = $brands->fetch_assoc()): ?><option <?= $filters['brand'] === $brand['brand'] ? 'selected' : '' ?> value="<?= h($brand['brand']) ?>"><?= h($brand['brand']) ?></option><?php endwhile; ?></select></div>
    <div class="filter-group"><label for="spec_key">Specification</label><select id="spec_key" name="spec_key"><option value="">Any Specification</option><?php while ($spec = $spec_keys->fetch_assoc()): ?><option <?= $filters['spec_key'] === $spec['spec_key'] ? 'selected' : '' ?> value="<?= h($spec['spec_key']) ?>"><?= h($spec['spec_key']) ?></option><?php endwhile; ?></select><label for="spec_value">Contains</label><input id="spec_value" name="spec_value" value="<?= h($filters['spec_value']) ?>" placeholder="e.g. 16GB"></div>
    <div class="filter-group"><label for="sort">Sort</label><select id="sort" name="sort"><?php foreach (['newest' => 'Newest', 'price_asc' => 'Price: Low to High', 'price_desc' => 'Price: High to Low', 'relevance' => 'Relevance'] as $key => $label): ?><option value="<?= h($key) ?>" <?= $filters['sort'] === $key ? 'selected' : '' ?>><?= h($label) ?></option><?php endforeach; ?></select></div>
    <button class="btn-filter">Apply Filters</button>
</form></aside>
<section class="results" aria-label="Search results">
<?php if ($search_error): ?><p class="empty-state"><?= h($search_error) ?></p>
<?php elseif (!$products): ?><p class="empty-state">No products found. Try different keywords or broaden your filters.</p>
<?php else: render_product_cards($products); endif; ?>
</section></div>
<?php include 'includes/footer.php'; ?>
