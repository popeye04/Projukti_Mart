<?php
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
// Server-side only. Never include this credential in HTML, JSON, or logs.
define('GROQ_API_KEY', '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');
define('GROQ_MODEL', 'llama3-70b-8192');
// Current replacement used only when Groq rejects the requested retired model.
define('GROQ_FALLBACK_MODEL', 'qwen/qwen3.6-27b');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$host = getenv("PM_DB_HOST") ?: "localhost";
$user = getenv("PM_DB_USER") ?: "root";
$pass = getenv("PM_DB_PASS") ?: "";
$db = getenv("PM_DB_NAME") ?: "projukti_mart";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($conn, 'utf8mb4');
require_once __DIR__ . '/includes/activity_log.php';

function db_run(string $sql, string $types = '', array $params = []): mysqli_stmt
{
    global $conn;
    $stmt = $conn->prepare($sql);
    if ($types !== '') { $stmt->bind_param($types, ...$params); }
    $stmt->execute();
    return $stmt;
}

function h($value): string { return htmlspecialchars(is_scalar($value) ? (string) $value : '', ENT_QUOTES, 'UTF-8'); }
function is_valid_email(string $email): bool
{
    return filter_var(trim($email), FILTER_VALIDATE_EMAIL) !== false;
}
function email_allowed_for_role(string $email, string $role): bool
{
    $email = strtolower(trim($email));
    if (!is_valid_email($email)) { return false; }
    if ($role === 'customer') { return preg_match('/@gmail\\.com$/', $email) === 1; }
    if ($role === 'admin') { return $email === 'admin@projuktimart.com'; }
    return $role === 'seller';
}
function role_home_path(string $role): string
{
    return match ($role) {
        'admin' => '/Project/admin/dashboard.php',
        'seller' => '/Project/seller/dashboard.php',
        default => '/Project/index.php',
    };
}
function input_text(array $source, string $key, string $default = ''): string
{
    return isset($source[$key]) && is_scalar($source[$key]) ? trim((string) $source[$key]) : $default;
}
function safe_redirect($destination): string
{
    if (!is_string($destination) || preg_match('/[\r\n\\\\]/', $destination)) { return '/Project/index.php'; }
    $parts = parse_url($destination);
    if ($parts === false || isset($parts['host']) || isset($parts['scheme'])) { return '/Project/index.php'; }
    $path = $parts['path'] ?? '';
    if (str_contains($path, '..') || !preg_match('~^(?:/Project/)?(?:index|product|category|cart|checkout|orders|profile|search_results)\.php$~', $path)) {
        return '/Project/index.php';
    }
    return str_starts_with($destination, '/') ? $destination : '/Project/' . $destination;
}
function product_image($url): string
{
    $url = trim((string) $url);
    if (filter_var($url, FILTER_VALIDATE_URL) && in_array(strtolower(parse_url($url, PHP_URL_SCHEME) ?? ''), ['http', 'https'], true)) { return $url; }
    $relative = ltrim(preg_replace('~^/Project/~', '', $url), '/');
    if ($relative !== '' && !str_contains($relative, '..') && is_file(__DIR__ . '/' . $relative)) { return '/Project/' . $relative; }
    return '/Project/assets/product-placeholder.svg';
}

// Only active accounts retain a session; pending sellers cannot bypass approval.
// Authenticate and expire sessions before any page-level mutation handler runs.
if (isset($_SESSION['user_id'])) {
    $expired = time() - (int) ($_SESSION['last_activity'] ?? 0) > 1800;
    $account = db_run('SELECT username, role, status FROM users WHERE user_id = ?', 'i', [(int) $_SESSION['user_id']])->get_result()->fetch_assoc();
    if ($expired || !$account || $account['status'] !== 'active') {
        $_SESSION = [];
        session_regenerate_id(true);
    } else {
        $_SESSION['username'] = $account['username'];
        $_SESSION['role'] = $account['role'];
    }
}
$_SESSION['last_activity'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf_token" value="' . h($_SESSION['csrf_token']) . '">'; }
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && !defined('PUBLIC_SEARCH_ENDPOINT')) {
    if (!hash_equals($_SESSION['csrf_token'], input_text($_POST, 'csrf_token'))) {
        http_response_code(403);
        exit('Your form has expired. Reload the page and try again.');
    }
}
