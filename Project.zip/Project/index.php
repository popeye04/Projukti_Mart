<?php
session_start();
require_once 'db.php';
require_once 'includes/recommendations.php';
$page_title = 'Home';
include 'includes/header.php';

// Top-level categories for the shop-by-category tiles
$categories = db_run(
    "SELECT category_id, category_name FROM categories WHERE parent_category_id IS NULL AND is_active = 1 ORDER BY category_name ASC"
)->get_result();

?>

<?php if (isset($_SESSION['store_error'])): ?>
<p class="stock-warning-box"><?= h($_SESSION['store_error']) ?></p>
<?php unset($_SESSION['store_error']); endif; ?>

<section class="hero">
    <div class="hero-text">
        <span class="eyebrow"><span class="status-dot" aria-hidden="true"></span> A little ahead of the everyday</span>
        <h1>Make room for<br>what’s <span>next.</span></h1>
        <p>From your next big idea to your everyday essentials. Discover mobiles, PCs, laptops, and the gear that makes it all happen.</p>
        <div class="hero-actions">
            <a href="#categories" class="btn-hero">Find your next upgrade <span aria-hidden="true">↗</span></a>
            <a href="#categories" class="hero-secondary">Explore the collection <span aria-hidden="true">→</span></a>
        </div>
        <div class="hero-meta"><span>Built for your world.</span><span>Priced in ৳. Made for Bangladesh.</span></div>
    </div>
    <div class="hero-visual" aria-hidden="true">
        <div class="visual-topline"><span>THE NEXT CHAPTER</span><span>PM / 01</span></div>
        <div class="device-scene">
            <div class="hero-orbit"></div>
            <div class="device-glow"></div>
            <div class="device-laptop">
                <div class="device-screen">
                    <div class="device-display"><span class="display-grid"></span><span class="display-orbit"></span><span class="display-mark display-word">P<span>m.</span></span><span class="display-caption">IDEAS. UNLIMITED.</span></div>
                </div>
                <div class="device-base"></div>
            </div>
        </div>
        <div class="visual-caption"><span>Less ordinary.<br><strong>More possibility.</strong></span><span class="visual-cross">+</span></div>
    </div>
</section>

<section id="categories" class="category-tiles">
    <div class="section-heading">
        <div><span class="eyebrow">Find your focus</span><h2>Good tech. Your way.</h2></div>
        <span class="section-index">01 / THE COLLECTION</span>
    </div>
    <div class="tile-grid">
        <?php if ($categories->num_rows === 0): ?>
            <p class="empty-state">Categories haven't been added yet.</p>
        <?php else: while ($cat = $categories->fetch_assoc()): ?>
            <a class="category-tile" href="category.php?category_id=<?php echo $cat['category_id']; ?>">
                <span class="tile-icon"><?php echo strtoupper(substr($cat['category_name'], 0, 1)); ?></span>
                <span class="tile-name"><?php echo h($cat['category_name']); ?></span>
                <span class="tile-caption">Explore the collection</span>
                <span class="tile-arrow" aria-hidden="true">↗</span>
            </a>
        <?php endwhile; endif; ?>
    </div>
</section>

<?php $recommended = recommendations(isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null); ?>
<?php if ($recommended['products']): ?>
<section class="recommendations">
    <div class="section-heading"><div><span class="eyebrow">Worth a closer look</span><h2><?= h($recommended['title']) ?></h2></div><span class="section-index">02 / DISCOVER MORE</span></div>
    <?php render_product_cards($recommended['products']); ?>
</section>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
