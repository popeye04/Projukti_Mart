<?php
session_start();
require_once 'db.php';

function shipping_fee_for_city(string $city): int
{
    $normalized = mb_strtolower(trim($city));
    return in_array($normalized, ['dhaka', 'dhaka city'], true) ? 60 : 150;
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=" . urlencode("checkout.php"));
    exit();
}

$user_id = intval($_SESSION['user_id']);
if (($_SESSION['role'] ?? '') !== 'customer') {
    $_SESSION['store_error'] = 'Only customer accounts can purchase products';
    header('Location: index.php'); exit;
}

// Fetch cart items joined with live product data
$items_stmt = $conn->prepare(
    "SELECT ci.cart_item_id, ci.quantity, p.product_id, p.name, p.price, p.stock_qty
     FROM cart_items ci
     JOIN cart c ON ci.cart_id = c.cart_id
     JOIN products p ON ci.product_id = p.product_id
     WHERE c.user_id = ?"
);
$items_stmt->bind_param("i", $user_id);
$items_stmt->execute();
$cart_result = $items_stmt->get_result();

$cart_rows = [];
$subtotal = 0;
while ($row = $cart_result->fetch_assoc()) {
    $row['line_total'] = $row['price'] * $row['quantity'];
    $subtotal += $row['line_total'];
    $cart_rows[] = $row;
}

if (empty($cart_rows)) {
    header("Location: cart.php");
    exit();
}

// Fetch saved addresses
$addr_stmt = $conn->prepare("SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, address_id DESC");
$addr_stmt->bind_param("i", $user_id);
$addr_stmt->execute();
$addresses_result = $addr_stmt->get_result();
$addresses = [];
while ($a = $addresses_result->fetch_assoc()) {
    $addresses[] = $a;
}

$selected_address_id = (int) ($_POST['address_id'] ?? 0);
$selected_city = input_text($_POST, 'city');
foreach ($addresses as $address) {
    if (($selected_address_id && $selected_address_id === (int) $address['address_id']) || (!$selected_address_id && $address['is_default'])) {
        $selected_city = $address['city'];
        break;
    }
}
$shipping_fee = shipping_fee_for_city($selected_city);
$total = $subtotal + $shipping_fee;

$error = '';
$order_placed = false;
$placed_order_id = null;
$placed_total = 0;

// Lock cart, address, then products in deterministic order; read live quantities.
if (isset($_POST['place_order'])) {
    try {
        $conn->begin_transaction();
        $cart = db_run('SELECT cart_id FROM cart WHERE user_id = ? FOR UPDATE', 'i', [$user_id])->get_result()->fetch_assoc();
        if (!$cart) { throw new InvalidArgumentException('Your cart is empty.'); }
        $address_id = (int) ($_POST['address_id'] ?? 0);
        if (isset($_POST['add_inline_address'])) {
            $address_values = [];
            foreach (['line1' => 150, 'line2' => 150, 'city' => 50, 'postal_code' => 20, 'country' => 50] as $key => $limit) {
                $value = input_text($_POST, $key);
                if (strlen($value) > $limit || (in_array($key, ['line1', 'city', 'country'], true) && $value === '')) {
                    throw new InvalidArgumentException('Enter a complete shipping address within the field limits.');
                }
                $address_values[] = $value;
            }
            // Match profile.php's per-account lock when selecting a default address.
            db_run('SELECT user_id FROM users WHERE user_id = ? FOR UPDATE', 'i', [$user_id]);
            $has_address = db_run('SELECT address_id FROM addresses WHERE user_id = ? LIMIT 1', 'i', [$user_id])->get_result()->fetch_assoc();
            $saved_address = db_run('INSERT INTO addresses (user_id, line1, line2, city, postal_code, country, is_default) VALUES (?, ?, ?, ?, ?, ?, ?)', 'isssssi', array_merge([$user_id], $address_values, [$has_address ? 0 : 1]));
            $address_id = (int) $saved_address->insert_id;
        }
        $shipping_address = db_run('SELECT address_id, city FROM addresses WHERE address_id = ? AND user_id = ? FOR UPDATE', 'ii', [$address_id, $user_id])->get_result()->fetch_assoc();
        if (!$shipping_address) {
            throw new InvalidArgumentException('Select one of your saved shipping addresses.');
        }
        $live_items = db_run('SELECT product_id, quantity FROM cart_items WHERE cart_id = ? ORDER BY product_id FOR UPDATE', 'i', [$cart['cart_id']])->get_result()->fetch_all(MYSQLI_ASSOC);
        if (!$live_items) { throw new InvalidArgumentException('Your cart is empty or this order has already been placed.'); }
        $order_cents = 0;
        $locked_items = [];
        foreach ($live_items as $item) {
            $live = db_run("SELECT p.name, p.price, p.stock_qty FROM products p JOIN categories c ON c.category_id = p.category_id LEFT JOIN categories parent ON parent.category_id = c.parent_category_id WHERE p.product_id = ? AND p.status = 'active' AND c.is_active = 1 AND (parent.category_id IS NULL OR parent.is_active = 1) FOR UPDATE", 'i', [$item['product_id']])->get_result()->fetch_assoc();
            if (!$live || $item['quantity'] < 1 || $live['stock_qty'] < $item['quantity']) {
                throw new InvalidArgumentException('An item is unavailable or has insufficient stock. Please update your cart.');
            }
            $line_cents = (int) round((float) $live['price'] * 100) * (int) $item['quantity'];
            $order_cents += $line_cents;
            if ($order_cents > 9999999999) { throw new InvalidArgumentException('Order total exceeds the supported limit.'); }
            $locked_items[] = array_merge($item, ['unit_price' => $live['price'], 'subtotal' => $line_cents / 100]);
        }
        $shipping_cents = shipping_fee_for_city($shipping_address['city']) * 100;
        $order_total = ($order_cents + $shipping_cents) / 100;
        $order_stmt = db_run("INSERT INTO orders (user_id, address_id, status, total_amount) VALUES (?, ?, 'pending', ?)", 'iid', [$user_id, $address_id, $order_total]);
        $order_id = $order_stmt->insert_id;
        db_run("INSERT INTO order_status_history (order_id, old_status, new_status, changed_by) VALUES (?, NULL, 'pending', ?)", 'ii', [$order_id, $user_id]);
        foreach ($locked_items as $item) {
            db_run('INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)', 'iiidd', [$order_id, $item['product_id'], $item['quantity'], $item['unit_price'], $item['subtotal']]);
        }
        db_run('DELETE ci FROM cart_items ci JOIN cart c ON c.cart_id = ci.cart_id WHERE c.cart_id = ? AND c.user_id = ?', 'ii', [$cart['cart_id'], $user_id]);
        log_activity($conn, 'order_placed', 'order', (int) $order_id);
        $conn->commit();
        $order_placed = true;
        $placed_order_id = $order_id;
        $placed_total = $order_total;
    } catch (Throwable $exception) {
        $conn->rollback();
        $error = $exception instanceof InvalidArgumentException ? $exception->getMessage() : 'Unable to place your order. Nothing was charged; please try again.';
    }
}

$page_title = 'Checkout';
include 'includes/header.php';

// Build the order-items table once, reused whether or not an address exists
ob_start();
?>
<h2>Order Items</h2>
<table class="cart-table">
    <thead>
        <tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr>
    </thead>
    <tbody>
        <?php foreach ($cart_rows as $row): ?>
        <tr>
            <td><?php echo h($row['name']); ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td>৳<?php echo number_format($row['price'], 2); ?></td>
            <td>৳<?php echo number_format($row['line_total'], 2); ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php
$order_items_html = ob_get_clean();
?>

<div class="page-heading">
    <p class="page-eyebrow">Make it yours</p>
    <h1>Checkout</h1>
    <p class="page-intro">Good technology. Delivered to your door.</p>
</div>

<?php if ($order_placed): ?>
    <div class="order-confirmation">
        <h2>Order Placed!</h2>
        <p>Thanks for your order — <strong>Order #<?php echo $placed_order_id; ?></strong> has been placed successfully.</p>
        <p>Order total: <strong>৳<?php echo number_format($placed_total, 2); ?></strong></p>
        <a href="orders.php" class="btn-hero">View My Orders</a>
    </div>
<?php else: ?>

    <ol class="checkout-steps" aria-label="Checkout progress">
        <li><span>01</span> Cart</li>
        <li aria-current="step"><span>02</span> Address &amp; review</li>
        <li><span>03</span> Confirmation</li>
    </ol>

    <?php if ($error): ?><p class="stock-warning-box"><?php echo h($error); ?></p><?php endif; ?>

    <div class="checkout-layout">
        <div class="checkout-main">
            <section class="checkout-section">
                <form method="POST"><?= csrf_field() ?>
                    <h2>Shipping Address</h2>
                    <?php if (empty($addresses)): ?>
                        <input type="hidden" name="add_inline_address" value="1">
                        <p class="muted">Enter your address below. It will be saved when your order is placed.</p>
                        <div class="form-grid">
                        <?php foreach (['line1' => 'Address Line 1', 'line2' => 'Address Line 2 (optional)', 'city' => 'City', 'postal_code' => 'Postal Code (optional)', 'country' => 'Country'] as $key => $label): ?>
                            <div class="filter-group"><label for="<?= h($key) ?>"><?= h($label) ?></label>
                            <input id="<?= h($key) ?>" name="<?= h($key) ?>" value="<?= h(input_text($_POST, $key, $key === 'country' ? 'Bangladesh' : '')) ?>" <?= in_array($key, ['line1', 'city', 'country'], true) ? 'required' : '' ?>></div>
                        <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="address-options">
                        <?php foreach ($addresses as $addr): ?>
                            <label class="address-option"><input type="radio" name="address_id" value="<?= (int) $addr['address_id'] ?>" data-shipping-fee="<?= shipping_fee_for_city($addr['city']) ?>" <?= (isset($_POST['address_id']) ? (int) $_POST['address_id'] === (int) $addr['address_id'] : (bool) $addr['is_default']) ? 'checked' : '' ?> required>
                            <span><?= h($addr['line1']) ?><?= $addr['line2'] ? ', ' . h($addr['line2']) : '' ?><br><?= h($addr['city']) ?>, <?= h($addr['country']) ?></span></label>
                        <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <?= $order_items_html ?>
                    <button type="submit" name="place_order" class="btn-hero">Place Order</button>
                </form>
            </section>
        </div>

        <aside class="checkout-summary">
            <h3>Order Summary</h3>
            <div class="summary-row"><span>Subtotal</span><span>৳<?php echo number_format($subtotal, 2); ?></span></div>
            <div class="summary-row"><span>Shipping</span><span id="shipping-fee">৳<?php echo number_format($shipping_fee, 2); ?></span></div>
            <p class="muted">৳60 inside Dhaka · ৳150 outside Dhaka</p>
            <div class="summary-row total"><span>Total</span><span id="checkout-total" data-subtotal="<?= h($subtotal) ?>">৳<?php echo number_format($total, 2); ?></span></div>
        </aside>
    </div>

<?php endif; ?>

<script>
(() => {
    const fee = document.getElementById('shipping-fee');
    const total = document.getElementById('checkout-total');
    if (!fee || !total) return;
    const subtotal = Number(total.dataset.subtotal);
    const format = amount => `৳${amount.toLocaleString('en-BD', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    document.querySelectorAll('input[name="address_id"][data-shipping-fee]').forEach(address => {
        address.addEventListener('change', () => {
            const shipping = Number(address.dataset.shippingFee);
            fee.textContent = format(shipping);
            total.textContent = format(subtotal + shipping);
        });
    });
    const city = document.querySelector('input[name="city"]');
    city?.addEventListener('input', () => {
        const shipping = ['dhaka', 'dhaka city'].includes(city.value.trim().toLowerCase()) ? 60 : 150;
        fee.textContent = format(shipping);
        total.textContent = format(subtotal + shipping);
    });
})();
</script>

<?php include 'includes/footer.php'; ?>
