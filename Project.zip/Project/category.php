<?php
session_start();
require_once 'db.php';
require_once 'includes/recommendations.php';

$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;

$cat_stmt = $conn->prepare("SELECT category_id, category_name, is_active FROM categories c WHERE category_id = ? AND NOT EXISTS (SELECT 1 FROM categories parent WHERE parent.category_id = c.parent_category_id AND parent.is_active = 0)");
$cat_stmt->bind_param("i", $category_id);
$cat_stmt->execute();
$category = $cat_stmt->get_result()->fetch_assoc();

if (!$category || !$category['is_active']) {
    header("Location: index.php");
    exit();
}

$page_title = $category['category_name'];
include 'includes/header.php';

// Subcategories under this one, if any
$sub_stmt = $conn->prepare("SELECT category_id, category_name FROM categories WHERE parent_category_id = ? AND is_active = 1");
$sub_stmt->bind_param("i", $category_id);
$sub_stmt->execute();
$subcategories = $sub_stmt->get_result();

// Products shown here come from this category AND any of its subcategories
$category_ids = [$category_id];
if ($subcategories->num_rows > 0) {
    $subcategories->data_seek(0);
    while ($sub = $subcategories->fetch_assoc()) {
        $category_ids[] = $sub['category_id'];
    }
    $subcategories->data_seek(0);
}

$filters = search_filters($_GET);
$filters['cat'] = $category_id;
$seller_id = (($_SESSION['role'] ?? '') === 'seller' && isset($_SESSION['user_id']))
    ? (int) $_SESSION['user_id']
    : null;
$min_price = $filters['min_price'];
$max_price = $filters['max_price'];
$brand = $filters['brand'];
$sort = $filters['sort'];
$seller_scope = $seller_id === null ? '' : ' AND p.seller_id = ?';
$scope_types = $seller_id === null ? 'ii' : 'iii';
$scope_params = $seller_id === null ? [$category_id, $category_id] : [$category_id, $category_id, $seller_id];
$brands = db_run("SELECT DISTINCT p.brand FROM products p JOIN categories c ON c.category_id = p.category_id WHERE (c.category_id = ? OR c.parent_category_id = ?) AND p.status = 'active' AND p.brand IS NOT NULL$seller_scope ORDER BY p.brand", $scope_types, $scope_params)->get_result();
$spec_keys = db_run("SELECT DISTINCT ps.spec_key FROM product_specs ps JOIN products p ON p.product_id = ps.product_id JOIN categories c ON c.category_id = p.category_id WHERE (c.category_id = ? OR c.parent_category_id = ?) AND p.status = 'active'$seller_scope ORDER BY ps.spec_key", $scope_types, $scope_params)->get_result();
$products = search_products('', $filters, 200, null, [], $seller_id);
?>

<nav class="breadcrumb" aria-label="Breadcrumb">
    <a href="index.php">Home</a> / <span><?php echo h($category['category_name']); ?></span>
</nav>

<div class="category-layout">
    <aside class="filters catalog-filters" aria-label="Product filters">
        <span class="eyebrow">Make it yours</span>
        <?php if ($subcategories->num_rows > 0): ?>
        <div class="filter-group">
            <label>Subcategory</label>
            <ul class="subcat-list">
                <?php while ($sub = $subcategories->fetch_assoc()): ?>
                    <li><a href="category.php?category_id=<?php echo $sub['category_id']; ?>"><?php echo h($sub['category_name']); ?></a></li>
                <?php endwhile; ?>
            </ul>
        </div>
        <?php endif; ?>

        <h3>Refine your search</h3>
        <form method="GET" action="category.php">
            <input type="hidden" name="category_id" value="<?php echo $category_id; ?>">

            <div class="filter-group">
                <label>Price Range (৳)</label>
                <div class="price-inputs">
                    <input type="number" name="min_price" placeholder="Min" value="<?php echo h($min_price ?? ''); ?>">
                    <input type="number" name="max_price" placeholder="Max" value="<?php echo h($max_price ?? ''); ?>">
                </div>
            </div>

            <?php if ($brands->num_rows > 0): ?>
            <div class="filter-group">
                <label for="brand">Brand</label>
                <select name="brand" id="brand">
                    <option value="">All Brands</option>
                    <?php while ($b = $brands->fetch_assoc()): ?>
                        <option value="<?php echo h($b['brand']); ?>" <?php echo ($brand === $b['brand']) ? 'selected' : ''; ?>>
                            <?php echo h($b['brand']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="filter-group">
                <label for="sort">Sort by</label>
                <select name="sort" id="sort">
                    <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest</option>
                    <option value="price_asc" <?php echo $sort === 'price_asc' ? 'selected' : ''; ?>>Price: Low to High</option>
                    <option value="price_desc" <?php echo $sort === 'price_desc' ? 'selected' : ''; ?>>Price: High to Low</option>
                </select>
            </div>

            <div class="filter-group">
                <label for="spec_key">Specification</label>
                <select id="spec_key" name="spec_key"><option value="">Any Specification</option>
                    <?php while ($spec = $spec_keys->fetch_assoc()): ?>
                    <option value="<?= h($spec['spec_key']) ?>" <?= $filters['spec_key'] === $spec['spec_key'] ? 'selected' : '' ?>><?= h($spec['spec_key']) ?></option>
                    <?php endwhile; ?>
                </select>
                <label for="spec_value">Contains</label><input id="spec_value" name="spec_value" value="<?= h($filters['spec_value']) ?>" placeholder="e.g. 16GB">
            </div>
            <button type="submit" class="btn-filter">Apply Filters</button>
        </form>
    </aside>

    <section class="results">
        <div class="results-header">
            <div><span class="eyebrow"><?php echo $seller_id === null ? 'The collection' : 'Your listings'; ?></span><h1><?php echo h($category['category_name']); ?></h1></div>
            <p class="muted">Find the right fit for your everyday.</p>
        </div>

        <?php if (!$products): ?>
            <p class="empty-state">No products found. Try adjusting your filters.</p>
        <?php else: render_product_cards($products); endif; ?>
    </section>
</div>

<?php $recommended = $seller_id === null ? recommendations(isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null) : ['products' => []]; if ($recommended['products']): ?>
<section class="recommendations"><div class="section-heading"><div><span class="eyebrow">Keep exploring</span><h2><?= h($recommended['title']) ?></h2></div><span class="section-index">DISCOVER MORE ↗</span></div><?php render_product_cards($recommended['products'], 'recommendation-carousel'); ?></section>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
