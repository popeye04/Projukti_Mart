<?php
session_start();
require_once 'db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ' . role_home_path((string) ($_SESSION['role'] ?? 'customer')));
    exit();
}

$error = '';
$notice = $_SESSION['approval_notice'] ?? '';
unset($_SESSION['approval_notice']);
$requested_redirect = input_text($_POST, 'redirect', input_text($_GET, 'redirect'));
$redirect = safe_redirect($requested_redirect === '' ? 'index.php' : $requested_redirect);

$forgot_error = '';
$forgot_notice = '';
$show_reset_form = false;
$forgot_mode = input_text($_GET, 'forgot') === '1';
$forgot_email = input_text($_POST, 'forgot_email');
$forgot_phone = input_text($_POST, 'forgot_phone');

if (isset($_POST['forgot_request'])) {
    $forgot_mode = true;
    $forgot_email = input_text($_POST, 'forgot_email');
    $forgot_phone = input_text($_POST, 'forgot_phone');

    if (!is_valid_email($forgot_email)) {
        $forgot_error = 'Please enter a valid email address.';
    } elseif ($forgot_phone === '') {
        $forgot_error = 'Please enter your phone number.';
    } else {
        $stmt = $conn->prepare("SELECT user_id, username, email, phone, role FROM users WHERE email = ? AND phone = ?");
        $stmt->bind_param("ss", $forgot_email, $forgot_phone);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && email_allowed_for_role($user['email'], $user['role'])) {
            $_SESSION['forgot_user_id'] = (int) $user['user_id'];
            $_SESSION['forgot_username'] = $user['username'];
            // A verified reset may only be completed during this short-lived flow.
            $_SESSION['forgot_reset_expires'] = time() + 900;
            $forgot_notice = 'Hi ' . h($user['username']) . ', please reset your password.';
            $show_reset_form = true;
        } else {
            $forgot_error = 'The email and phone number did not match an eligible account.';
        }
    }
}

if (isset($_POST['reset_password'])) {
    $forgot_mode = true;
    $new_password = is_string($_POST['new_password'] ?? null) ? $_POST['new_password'] : '';
    $confirm_password = is_string($_POST['confirm_password'] ?? null) ? $_POST['confirm_password'] : '';
    $forgot_user_id = isset($_SESSION['forgot_user_id']) ? (int) $_SESSION['forgot_user_id'] : 0;
    $reset_expires = isset($_SESSION['forgot_reset_expires']) ? (int) $_SESSION['forgot_reset_expires'] : 0;

    if ($forgot_user_id <= 0 || $reset_expires < time()) {
        unset($_SESSION['forgot_user_id'], $_SESSION['forgot_username'], $_SESSION['forgot_reset_expires']);
        $forgot_error = 'Start the password reset flow by entering your email and phone number.';
    } elseif ($new_password !== $confirm_password || strlen($new_password) < 6 || strlen($new_password) > 72) {
        $forgot_error = 'New password and confirm password must match and contain 6 to 72 bytes.';
    } else {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        db_run('UPDATE users SET password = ? WHERE user_id = ?', 'si', [$hashed, $forgot_user_id]);
        unset($_SESSION['forgot_user_id'], $_SESSION['forgot_username'], $_SESSION['forgot_reset_expires']);
        $forgot_notice = 'Password changed successfully. You can now login with your new password.';
        $show_reset_form = false;
        $forgot_mode = false;
    }
}

if (isset($_POST['login'])) {
    $email = input_text($_POST, 'email');
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    $email_key = strtolower($email);
    $now = time();

    if (($blocked_until = $_SESSION['login_lock_until'][$email_key] ?? 0) > $now) {
        $remaining = max(1, $blocked_until - $now);
        $error = 'Too many failed login attempts. Please wait ' . $remaining . ' second' . ($remaining === 1 ? '' : 's') . ' before trying again.';
    } else {
        $stmt = $conn->prepare("SELECT user_id, username, password, email, role, status FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if (!$user || !email_allowed_for_role($user['email'], $user['role']) || !password_verify($password, $user['password'])) {
            log_activity($conn, 'failed_login', 'user', $user ? (int) $user['user_id'] : null);
            $attempts = (int) ($_SESSION['login_attempts'][$email_key] ?? 0) + 1;
            $_SESSION['login_attempts'][$email_key] = $attempts;

            if ($attempts >= 3) {
                $_SESSION['login_lock_until'][$email_key] = $now + 10;
                $_SESSION['login_attempts'][$email_key] = 0;
                $error = 'Too many failed login attempts. You are blocked for 10 seconds.';
            } else {
                $error = 'Invalid email or password.';
            }
        } elseif ($user['status'] === 'pending_approval') {
            log_activity($conn, 'failed_login', 'user', (int) $user['user_id']);
            $error = 'Your seller account is awaiting admin approval';
        } elseif ($user['status'] !== 'active') {
            log_activity($conn, 'failed_login', 'user', (int) $user['user_id']);
            $error = 'This account has been suspended. Please contact support.';
        } else {
            unset($_SESSION['login_attempts'][$email_key], $_SESSION['login_lock_until'][$email_key]);
            unset($_SESSION['forgot_user_id'], $_SESSION['forgot_username'], $_SESSION['forgot_reset_expires']);
            session_regenerate_id(true);
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['last_activity'] = time();
            log_activity($conn, 'login', 'user', (int) $user['user_id']);

            // Return to a protected page when one was requested; otherwise open
            // the workspace that belongs to the authenticated role.
            header('Location: ' . ($requested_redirect === '' ? role_home_path($user['role']) : $redirect));
            exit();
        }
    }
}

$page_title = 'Login';
include 'includes/header.php';
?>

<div class="auth-wrapper">
    <div class="auth-card">
        <p class="page-eyebrow"><?php echo $forgot_mode ? 'Account recovery' : 'Back to your world'; ?></p>
        <h1><?php echo $forgot_mode ? 'Reset Password' : 'Login'; ?></h1>
        <p class="auth-caption"><?php echo $forgot_mode ? 'Verify your account, then choose a new password.' : 'Your next upgrade is waiting. Welcome back.'; ?></p>
        <?php if ($notice): ?><p class="cart-message"><?= h($notice) ?></p><?php endif; ?>
        <?php if ($forgot_notice && !$forgot_mode): ?><p class="cart-message"><?php echo h($forgot_notice); ?></p><?php endif; ?>
        <?php if ($error): ?><p class="stock-warning-box"><?php echo h($error); ?></p><?php endif; ?>

        <?php if (!$forgot_mode): ?>
        <form method="POST"><?= csrf_field() ?>
            <input type="hidden" name="redirect" value="<?php echo h($redirect); ?>">
            <div class="filter-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo h(input_text($_POST, 'email')); ?>" required>
            </div>
            <div class="filter-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="login" class="btn-hero auth-submit">Login</button>
        </form>

        <p class="auth-switch">
            <a href="login.php?forgot=1">Forgot password?</a>
        </p>
        <?php else: ?>

        <div id="forgot-panel" class="filter-group" style="margin-top: 12px;">
            <?php if ($forgot_error): ?><p class="stock-warning-box"><?php echo h($forgot_error); ?></p><?php endif; ?>
            <?php if ($forgot_notice): ?><p class="cart-message"><?php echo h($forgot_notice); ?></p><?php endif; ?>

            <?php if (!$show_reset_form): ?>
                <form method="POST"><?= csrf_field() ?>
                    <div class="filter-group">
                        <label for="forgot_email">Email</label>
                        <input type="email" id="forgot_email" name="forgot_email" value="<?php echo h($forgot_email); ?>" required>
                    </div>
                    <div class="filter-group">
                        <label for="forgot_phone">Phone</label>
                        <input type="text" id="forgot_phone" name="forgot_phone" value="<?php echo h($forgot_phone); ?>" required>
                    </div>
                    <button type="submit" name="forgot_request" class="btn-filter">Verify Email & Phone</button>
                </form>
            <?php else: ?>
                <form method="POST"><?= csrf_field() ?>
                    <input type="hidden" name="forgot_email" value="<?php echo h($forgot_email); ?>">
                    <input type="hidden" name="forgot_phone" value="<?php echo h($forgot_phone); ?>">
                    <div class="filter-group">
                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" name="new_password" required>
                    </div>
                    <div class="filter-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" name="reset_password" class="btn-filter">Reset Password</button>
                </form>
            <?php endif; ?>
        </div>
        <p class="auth-switch"><a href="login.php">Back to login</a></p>
        <?php endif; ?>

        <p class="auth-switch">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
