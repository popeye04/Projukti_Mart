<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=" . urlencode("cart.php"));
    exit();
}

$user_id = intval($_SESSION['user_id']);
if (($_SESSION['role'] ?? '') !== 'customer') {
    $_SESSION['store_error'] = 'Only customer accounts can purchase products';
    header('Location: index.php'); exit;
}

$cart_error = '';
if (isset($_POST['update_cart']) || isset($_POST['remove'])) {
    try {
        $conn->begin_transaction();
        $owned_cart = db_run('SELECT cart_id FROM cart WHERE user_id = ? FOR UPDATE', 'i', [$user_id])->get_result()->fetch_assoc();
        if (!$owned_cart) { throw new InvalidArgumentException('Cart not found.'); }
        if (isset($_POST['remove'])) {
            db_run('DELETE ci FROM cart_items ci JOIN cart c ON c.cart_id = ci.cart_id WHERE ci.cart_item_id = ? AND c.user_id = ?', 'ii', [(int) $_POST['remove'], $user_id]);
        } else {
            $quantities = $_POST['quantity'] ?? [];
            if (!is_array($quantities)) { throw new InvalidArgumentException('Invalid quantities.'); }
            foreach ($quantities as $cart_item_id => $qty) {
                $qty = filter_var($qty, FILTER_VALIDATE_INT);
                if ($qty === false || $qty < 1) { throw new InvalidArgumentException('Quantities must be positive whole numbers.'); }
                $item = db_run('SELECT p.stock_qty, p.status FROM cart_items ci JOIN cart c ON c.cart_id = ci.cart_id JOIN products p ON p.product_id = ci.product_id WHERE ci.cart_item_id = ? AND c.user_id = ? FOR UPDATE', 'ii', [(int) $cart_item_id, $user_id])->get_result()->fetch_assoc();
                if (!$item) { throw new InvalidArgumentException('Cart item not found.'); }
                if ($item['stock_qty'] <= 0 || $item['status'] !== 'active') {
                    db_run('DELETE ci FROM cart_items ci JOIN cart c ON c.cart_id = ci.cart_id WHERE ci.cart_item_id = ? AND c.user_id = ?', 'ii', [(int) $cart_item_id, $user_id]);
                } else {
                    if ($qty > (int) $item['stock_qty']) { throw new InvalidArgumentException('Cart quantity cannot exceed the available stock of ' . (int) $item['stock_qty'] . '.'); }
                    db_run('UPDATE cart_items ci JOIN cart c ON c.cart_id = ci.cart_id SET ci.quantity = ? WHERE ci.cart_item_id = ? AND c.user_id = ?', 'iii', [$qty, (int) $cart_item_id, $user_id]);
                }
            }
        }
        $conn->commit();
        header('Location: cart.php'); exit;
    } catch (Throwable $exception) {
        $conn->rollback();
        $cart_error = $exception instanceof InvalidArgumentException ? $exception->getMessage() : 'Unable to update your cart.';
    }
}

$page_title = 'My Cart';
include 'includes/header.php';

$items_stmt = $conn->prepare(
    "SELECT ci.cart_item_id, ci.quantity, p.product_id, p.name, p.price, p.stock_qty
     FROM cart_items ci
     JOIN cart c ON ci.cart_id = c.cart_id
     JOIN products p ON ci.product_id = p.product_id
     WHERE c.user_id = ?
     ORDER BY ci.cart_item_id DESC"
);
$items_stmt->bind_param("i", $user_id);
$items_stmt->execute();
$items = $items_stmt->get_result();

$subtotal = 0;
$cart_rows = [];
while ($row = $items->fetch_assoc()) {
    $row['line_total'] = $row['price'] * $row['quantity'];
    $subtotal += $row['line_total'];
    $cart_rows[] = $row;
}
?>

<div class="page-heading">
    <p class="page-eyebrow">Your next upgrade</p>
    <h1>My Cart</h1>
    <p class="page-intro">A few good choices. One great setup.</p>
</div><?php if ($cart_error): ?><p class="stock-warning-box"><?= h($cart_error) ?></p><?php endif; ?>

<?php if (empty($cart_rows)): ?>
    <p class="empty-state">Your cart is empty. <a href="index.php">Continue shopping</a>.</p>
<?php else: ?>

<div class="cart-layout">
<div class="cart-content">
<form method="POST" class="cart-table-form"><?= csrf_field() ?>
    <table class="cart-table">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cart_rows as $row): ?>
            <tr>
                <td>
                    <a href="product.php?id=<?php echo $row['product_id']; ?>"><?php echo h($row['name']); ?></a>
                    <?php if ($row['quantity'] > $row['stock_qty']): ?>
                        <p class="stock-warning">Only <?php echo $row['stock_qty']; ?> left in stock</p>
                    <?php endif; ?>
                </td>
                <td>৳<?php echo number_format($row['price'], 2); ?></td>
                <td>
                    <input
                        type="number"
                        name="quantity[<?php echo $row['cart_item_id']; ?>]"
                        value="<?php echo $row['quantity']; ?>"
                        min="1"
                        max="<?php echo $row['stock_qty']; ?>"
                    >
                </td>
                <td>৳<?php echo number_format($row['line_total'], 2); ?></td>
                <td><button class="remove-link" name="remove" value="<?= (int) $row['cart_item_id'] ?>" formnovalidate>Remove</button></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="cart-actions">
        <button type="submit" name="update_cart" class="btn-filter">Update Cart</button>
    </div>
</form>
</div>

<div class="cart-summary">
    <p class="page-eyebrow">The details</p>
    <h2>Order summary</h2>
    <p>Subtotal <span>৳<?php echo number_format($subtotal, 2); ?></span></p>
    <a href="checkout.php" class="btn-hero">Proceed to Checkout</a>
    <p class="muted">Shipping calculated at checkout.</p>
</div>
</div>

<?php endif; ?>

<?php include 'includes/footer.php'; ?>
