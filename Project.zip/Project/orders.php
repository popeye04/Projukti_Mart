<?php
session_start();
require_once 'db.php';
require_once 'includes/order_actions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=" . urlencode("orders.php"));
    exit();
}

$user_id = intval($_SESSION['user_id']);
if (($_SESSION['role'] ?? '') !== 'customer') {
    $_SESSION['store_error'] = 'Use your seller or admin dashboard to view orders.';
    header('Location: index.php'); exit;
}
$message = '';

if (isset($_POST['cancel_order'])) {
    try {
        change_order_status((int) ($_POST['order_id'] ?? 0), 'cancelled', 'customer');
        $message = 'Order updated.';
    } catch (Throwable $exception) {
        $message = $exception instanceof InvalidArgumentException ? $exception->getMessage() : 'Unable to update this order. Please try again.';
    }
}

$page_title = 'My Orders';
include 'includes/header.php';

$orders_stmt = $conn->prepare(
    "SELECT o.order_id, o.status, o.total_amount, o.order_date,
            a.line1, a.line2, a.city, a.postal_code, a.country
     FROM orders o
     JOIN addresses a ON o.address_id = a.address_id
     WHERE o.user_id = ?
     ORDER BY o.order_date DESC"
);
$orders_stmt->bind_param("i", $user_id);
$orders_stmt->execute();
$orders = $orders_stmt->get_result();
?>

<div class="page-heading">
    <p class="page-eyebrow">From our store to your setup</p>
    <h1>My Orders</h1>
    <p class="page-intro">Follow every upgrade, from checkout to delivery.</p>
</div>

<?php if ($message): ?><p class="cart-message"><?php echo h($message); ?></p><?php endif; ?>

<?php if ($orders->num_rows === 0): ?>
    <p class="empty-state">You haven't placed any orders yet. <a href="index.php">Start shopping</a>.</p>
<?php else: ?>

<?php while ($order = $orders->fetch_assoc()):
    $oi_stmt = $conn->prepare(
        "SELECT oi.quantity, oi.unit_price, oi.subtotal, p.name, p.product_id
         FROM order_items oi
         JOIN products p ON oi.product_id = p.product_id
         WHERE oi.order_id = ?"
    );
    $oi_stmt->bind_param("i", $order['order_id']);
    $oi_stmt->execute();
    $order_items = $oi_stmt->get_result();
?>
<div class="order-card">
    <div class="order-header">
        <div>
            <h3>Order #<?php echo $order['order_id']; ?></h3>
            <p class="muted"><?php echo date('d M Y', strtotime($order['order_date'])); ?></p>
        </div>
        <span class="status-badge status-<?php echo $order['status']; ?>"><?php echo ucfirst($order['status']); ?></span>
    </div>

    <ol class="order-progress" aria-label="Order fulfilment stages">
        <li>Pending</li>
        <li>Processing</li>
        <li>Shipped</li>
        <li>Delivered</li>
    </ol>

    <table class="cart-table">
        <thead>
            <tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr>
        </thead>
        <tbody>
            <?php while ($item = $order_items->fetch_assoc()): ?>
            <tr>
                <td><a href="product.php?id=<?php echo $item['product_id']; ?>"><?php echo h($item['name']); ?></a></td>
                <td><?php echo $item['quantity']; ?></td>
                <td>৳<?php echo number_format($item['unit_price'], 2); ?></td>
                <td>৳<?php echo number_format($item['subtotal'], 2); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <div class="order-footer">
        <p class="order-address">
            Shipping to: <?php echo h($order['line1']); ?><?php echo $order['line2'] ? ', ' . h($order['line2']) : ''; ?>,
            <?php echo h($order['city']); ?>, <?php echo h($order['country']); ?>
        </p>
        <div class="order-total-row">
            <span>Total: <strong>৳<?php echo number_format($order['total_amount'], 2); ?></strong></span>
            <?php if (in_array($order['status'], ['pending', 'processing'], true)): ?>
                <form method="POST" class="cancel-form"><?= csrf_field() ?>
                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                    <button type="submit" name="cancel_order">Cancel Order</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endwhile; ?>

<?php endif; ?>

<?php include 'includes/footer.php'; ?>
