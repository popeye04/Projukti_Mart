# Projukti Mart

## Project Overview

Projukti Mart is a multi-seller electronics marketplace built with plain PHP, MySQL/MariaDB through MySQLi/mysqlnd, HTML, CSS, and vanilla JavaScript. It runs on XAMPP at **C:\xampp\htdocs\Project**, database **projukti_mart**, and **http://localhost/Project/**. There is no application framework, Composer dependency, JavaScript library, or build step.

The catalog includes Mobile, PC, Laptop, and accessories. Monetary values use Bangladeshi Taka (৳). The shopping assistant calls Groq over HTTPS using PHP cURL. Its key is stored server-side in root `db.php` as `GROQ_API_KEY`. The existing local semantic/keyword implementation remains the API-failure fallback.

**Status — 8 September 2026:** the ten requested commerce/admin compliance fixes are implemented: seller approval, customer-only purchases/reviews, admin product overrides, card specs/ratings, order-status history, update timestamps, activity logging, inline checkout addresses, and complete specification editing. The live database contains **15 tables**. Remaining SRS gaps are listed below; this is not a claim of full SRS compliance.

Requirement references come from [CSE327 PROJECT MILESTONE 01.pdf](CSE327%20PROJECT%20MILESTONE%2001.pdf). This update preserves `ai_search.php`, `assets/js/chatbot.js`, and chatbot panel code unchanged.

## Database Schema 

The authoritative supplied schema and sample data are in [projukti_mart.sql](projukti_mart.sql). The dump identifies MariaDB 10.4.32 and PHP 8.2.12, and does not contain executable `CREATE DATABASE` or `USE` statements: select/create the database before import.

In the following table, every `*_id` primary key is `INT(11) NOT NULL AUTO_INCREMENT`. Other columns are NOT NULL unless marked nullable. `CURRENT_TIMESTAMP` means the dump's `current_timestamp()` default. The dump explicitly specifies InnoDB and `utf8mb4_general_ci` for all tables except `reviews`, whose engine/charset are inherited from database/server defaults; configure those defaults appropriately.

| Table | Columns and data types |
| --- | --- |
| `users` | `user_id` PK; `username VARCHAR(50)`; `password VARCHAR(255)`; `role ENUM('admin','seller','customer') DEFAULT 'customer'`; `status ENUM('active','suspended','pending_approval') DEFAULT 'active'`; `full_name VARCHAR(100)` nullable; `email VARCHAR(100)` nullable; `phone VARCHAR(20)` nullable; `created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |
| `categories` | `category_id` PK; `category_name VARCHAR(50)`; `description TEXT` nullable; `parent_category_id INT(11)` nullable; `is_active TINYINT(1) DEFAULT 1` |
| `products` | `product_id` PK; `category_id INT(11)`; `seller_id INT(11)`; `name VARCHAR(150)`; `brand VARCHAR(50)` nullable; `model VARCHAR(50)` nullable; `description TEXT` nullable; `price DECIMAL(10,2)`; `stock_qty INT(11) DEFAULT 0`; `status ENUM('active','inactive') DEFAULT 'active'`; `created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`; `updated_at TIMESTAMP` nullable, default NULL, ON UPDATE CURRENT_TIMESTAMP |
| `product_specs` | `spec_id` PK; `product_id INT(11)`; `spec_key VARCHAR(50)`; `spec_value VARCHAR(100)` |
| `product_images` | `image_id` PK; `product_id INT(11)`; `image_url VARCHAR(255)`; `is_primary TINYINT(1) DEFAULT 0` |
| `cart` | `cart_id` PK; `user_id INT(11)`; `created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |
| `cart_items` | `cart_item_id` PK; `cart_id INT(11)`; `product_id INT(11)`; `quantity INT(11) DEFAULT 1`; `added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |
| `orders` | `order_id` PK; `user_id INT(11)`; `address_id INT(11)`; `status ENUM('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending'`; `total_amount DECIMAL(10,2)`; `order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP`; `updated_at TIMESTAMP` nullable, default NULL, ON UPDATE CURRENT_TIMESTAMP |
| `order_items` | `order_item_id` PK; `order_id INT(11)`; `product_id INT(11)`; `quantity INT(11)`; `unit_price DECIMAL(10,2)`; `subtotal DECIMAL(10,2)` |
| `reviews` | `review_id` PK; `product_id INT(11)`; `user_id INT(11)`; `rating TINYINT(4)`; `comment TEXT` nullable; `is_flagged TINYINT(1) DEFAULT 0`; `created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |
| `addresses` | `address_id` PK; `user_id INT(11)`; `line1 VARCHAR(150)`; `line2 VARCHAR(150)` nullable; `city VARCHAR(50)`; `postal_code VARCHAR(20)` nullable; `country VARCHAR(50)`; `is_default TINYINT(1) DEFAULT 0` |
| `search_query_log` | `query_id` PK; `user_id INT(11)` nullable; `raw_query VARCHAR(255)`; `used_ai TINYINT(1) DEFAULT 0`; `result_count INT(11) DEFAULT 0`; `searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |
| `product_views` | `view_id` PK; `user_id INT(11)` nullable; `product_id INT(11)`; `viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |
| `order_status_history` | `history_id` PK; `order_id INT(11)`; `old_status VARCHAR(20)` nullable; `new_status VARCHAR(20)`; `changed_by INT(11)` nullable; `notes TEXT` nullable; `changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |
| `activity_log` | `log_id` PK; `user_id INT(11)` nullable; `action VARCHAR(100)`; `target_type VARCHAR(50)` nullable; `target_id INT(11)` nullable; `ip_address VARCHAR(45)` nullable; `logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP` |

`addresses`, `search_query_log`, and `product_views` were added later according to the project handoff. The compliance migration is `migrations/001_compliance.sql`; it is rerunnable on XAMPP MariaDB and included at the end of the fresh-install dump. Seeded search log rows are sample data; the current assistant uses the Groq adapter.

### Relationships and indexes

Original foreign keys use `ON UPDATE CASCADE`; the new history/activity foreign keys use the default update restriction. The deletion behavior below is taken from the dump; “restrict” means no explicit `ON DELETE` action, so referenced rows cannot ordinarily be deleted.

| Foreign key | References | On delete |
| --- | --- | --- |
| `addresses.user_id` | `users.user_id` | CASCADE |
| `cart.user_id` | `users.user_id` | CASCADE |
| `cart_items.cart_id` | `cart.cart_id` | CASCADE |
| `cart_items.product_id` | `products.product_id` | CASCADE |
| `categories.parent_category_id` | `categories.category_id` | SET NULL |
| `products.category_id` | `categories.category_id` | Restrict |
| `products.seller_id` | `users.user_id` | Restrict |
| `product_specs.product_id` | `products.product_id` | CASCADE |
| `product_images.product_id` | `products.product_id` | CASCADE |
| `orders.user_id` | `users.user_id` | Restrict |
| `orders.address_id` | `addresses.address_id` | Restrict |
| `order_items.order_id` | `orders.order_id` | CASCADE |
| `order_items.product_id` | `products.product_id` | Restrict |
| `reviews.product_id` | `products.product_id` | CASCADE |
| `reviews.user_id` | `users.user_id` | CASCADE |
| `product_views.product_id` | `products.product_id` | CASCADE |
| `product_views.user_id` | `users.user_id` | SET NULL |
| `search_query_log.user_id` | `users.user_id` | SET NULL |
| `order_status_history.order_id` | `orders.order_id` | CASCADE |
| `order_status_history.changed_by` | `users.user_id` | SET NULL |
| `activity_log.user_id` | `users.user_id` | SET NULL |

New indexes support `(order_id, changed_at)` histories and `(action, logged_at)` / `logged_at` activity filtering. Activity target type/ID refers to different record types and is not a foreign key.

Unique indexes enforce `users.username`, `users.email`, `categories.category_name`, one `cart` per `user_id`, one `(cart_id, product_id)` pair in `cart_items`, and one `(user_id, product_id)` pair in `reviews`. Foreign key columns have supporting indexes. Nullable unique email values are allowed by the schema, although registration requests an email.

`products` has the **FULLTEXT index `ft_product_search (name, description)`**. Keyword search and local semantic fallback use prepared FULLTEXT queries with automatic LIKE fallback; successful Groq calls use catalog context.

The schema does not enforce a rating range, positive prices/quantities, nonnegative stock, one primary image per product, or one default address per user with CHECK/unique constraints. Application validation and transactional writes enforce business rules; direct SQL changes must preserve those rules too.

## Folder Structure

```text
Project/
├── README.md
├── CSE327 PROJECT MILESTONE 01.pdf
├── projukti_mart.sql
├── db.php
├── index.php
├── category.php
├── product.php
├── cart.php
├── checkout.php
├── orders.php
├── profile.php
├── login.php
├── logout.php
├── register.php
├── search_results.php
├── ai_search.php
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── search.php
│   ├── semantic_search.php
│   ├── recommendations.php
│   ├── order_actions.php
│   ├── activity_log.php
│   └── product_management.php
├── assets/
│   ├── product-placeholder.svg
│   ├── css/style.css
│   └── js/
│       ├── chatbot.js
│       └── product_management.js
├── admin/
│   ├── dashboard.php
│   ├── manage_products.php
│   ├── activity.php
│   ├── manage_categories.php
│   ├── manage_users.php
│   ├── manage_orders.php
│   └── moderate_reviews.php
├── seller/
│   ├── dashboard.php
│   ├── manage_products.php
│   ├── seller_orders.php
│   └── sales_summary.php
├── images/                    # Upload contents vary
├── migrations/001_compliance.sql
└── tests/
    ├── verify.py
    ├── browser.py
    ├── order_worker.php
    ├── search_contract.php
    ├── compliance.py
    └── compliance_browser.py
```

Uploads are saved under `images/` with generated filenames and `images/filename` database paths. JPG/JPEG/PNG/WebP files are checked by extension, MIME and image decoding, with a 5MB per-image and ten-image per-request limit. The first image is primary; optional URL fields are used if no files are chosen. Missing local images use the bundled placeholder.

## Files and What Each Does

| File | Responsibility and requirements |
| --- | --- |
| `db.php` | Connects with strict MySQLi errors and UTF-8, supplying prepared `db_run()`, escaped `h()`, input, image-path, local-redirect, and CSRF helpers. It refreshes account status/role and expires idle sessions before page mutation handlers, supporting FR-02/04/27 and NFR-05/06. |
| `includes/header.php` | Renders navigation, GET search, prepared cart count, role links, and a protected logout form. It supports FR-02/04/05/07/11/13 and uses absolute `/Project/` links from every directory. |
| `includes/footer.php` | Renders the footer and assistant panel with the requested IDs and an accessible message log. It retains visibility listeners and loads `chatbot.js` for FR-07/08 submission without duplicate toggle listeners. |
| `includes/search.php` | Supplies prepared FULLTEXT/LIKE retrieval, validated filters, deadlines, logging, and shared product cards for FR-06/08. Specs use EXISTS and image selection is singular, preventing duplicate products; sort SQL is allowlisted and data is bound. |
| `includes/semantic_search.php` | Retains the local FR-08 fallback used when Groq fails. It parses simple category/budget/specification intents before prepared FULLTEXT/LIKE retrieval. |
| `includes/recommendations.php` | Implements FR-10/31 retrieval for account view history, weekly popularity, and same-category alternatives. It aggregates before joining product/image data and silently returns an empty section on errors. |
| `includes/order_actions.php` | Centralizes FR-18/22/26 transitions in transactions with role, ownership and allowed-state checks. Records actor/time/notes history and timestamps, performs idempotent restocking/re-reservation, and renders scoped timelines. |
| `index.php` | Shows hero content, active category tiles, and recent-view recommendations for logged-in users, falling back to weekly trending products. It covers FR-05/10/31 and hides empty recommendation sections. |
| `category.php` | Implements FR-05/06 browsing of a category and its active immediate children with price, brand, sort, and specification filters. It shares search retrieval/cards and adds a recommendation row for listing-page FR-10 coverage. |
| `product.php` | Displays product details, seller, stock, specs, images, reviews and averages for FR-09/20. Cart additions lock the account cart/product for FR-11/12, reviews verify a delivered purchase for FR-19, and view logging plus same-category carousel support FR-10/31. |
| `cart.php` | Implements authenticated owned cart editing/removal and totals for FR-11–14. It locks the cart consistently with checkout, removes unavailable items during updates, and uses protected POST for mutations. |
| `checkout.php` | Implements customer-only FR-14–16 checkout with a saved address or inline first address. One transaction saves any new address, validates stock/prices, creates order/items/history/activity, decrements stock and clears the cart; failures roll back everything. |
| `orders.php` | Lists the current customer’s order history for FR-17. Pending or processing (Confirmed) orders can be cancelled through the shared locked FR-18 service; seller/admin accounts use their respective panels. |
| `profile.php` | Implements FR-03 personal details and address CRUD/default selection. Writes are ownership-scoped, default changes serialize per account, duplicate emails are handled, and addresses referenced by orders cannot be deleted. |
| `login.php` | Implements FR-02 email/password authentication, session renewal and local redirects. Pending sellers receive an awaiting-approval message, inactive accounts are blocked, and successful/failed logins are logged. |
| `logout.php` | Logs authenticated logout and destroys the session on protected POST. Direct GET renders confirmation. |
| `register.php` | Implements FR-01 hashing, required fields and duplicate validation. Customers become active and sign in immediately; sellers remain signed out with pending_approval until approved by an admin. |
| `search_results.php` | Implements independent FR-06/08 keyword search using GET `q`, `cat`, `min_price`, `max_price`, `brand`, `sort`, `spec_key`, and `spec_value`. It uses FULLTEXT then LIKE, logs `used_ai=0`, displays counts/empty states, and caps displayed results at 200 with a refinement notice. |
| `ai_search.php` | Calls Groq server-side with active catalog data and session conversation context; page-load initialization restores history. API failures use local search. Fixed relevance scores, unconditional high confidence for valid replies, ignored Groq category context and incomplete overall timing remain SRS gaps. |
| `assets/js/chatbot.js` | Uses vanilla fetch, safe product cards, session-history restoration and browser SpeechRecognition with Bangla/English selection. The browser message deadline is 9.5 seconds. This file was preserved during compliance work. |
| `seller/dashboard.php` | Shows seller-scoped products, distinct orders, pending orders and noncancelled line-item revenue. It supports FR-21–23 with stat cards and links to product, order and sales pages. |
| `seller/manage_products.php` | Session-starting entry point to the shared FR-21 product editor with seller ownership enforcement. Supports uploads/URL fallback, complete specification editing, retained validation values, transactions and update timestamps. |
| `seller/seller_orders.php` | Provides FR-22 seller-scoped order/line-item visibility and forward status updates. Transitions can include tracking notes; UC-04 timelines show recorded actors, times and notes. |
| `seller/sales_summary.php` | Implements FR-23 seller totals and per-product breakdowns for 7 days, 30 days, 12 months or all time. Prepared queries bind seller identity and exclude cancelled orders. |
| `admin/dashboard.php` | Supports FR-24–27 with platform counts, noncancelled order value, flagged reviews and management links. It is the former root `dashboard.php` in its correct admin location. |
| `admin/manage_categories.php` | Implements FR-24 lifecycle with protected POST and transactions. Server checks reject self-parenting, a third level, and children beneath a category that still directly contains products; duplicate/restricted deletes are handled. |
| `admin/manage_users.php` | Implements FR-25/27 accounts/roles with a separate pending-seller approval list. Protected admin POST approves sellers; self-demotion/suspension is blocked and suspension events are logged. |
| `admin/manage_orders.php` | Provides platform order monitoring and controlled status changes for FR-26. Displays actor/time/notes histories and shares inventory and cancellation safeguards. |
| `admin/moderate_reviews.php` | Provides protected FR-26 flag/unflag actions and logs flag events. Flagged reviews are excluded from public lists and card/detail averages. |
| `tests/order_worker.php` | CLI-only integration worker for concurrent FR-18 cancellation. It refuses ordinary store databases and invokes the same order service used by the UI. |
| `tests/search_contract.php` | CLI-only FR-28/30 and NFR-02 parser/deadline assertions. It checks budget notation and expired retrieval deadlines in an isolated database. |
| `includes/product_management.php` | Shared seller/admin editor. Admin override is enabled only by the admin entry point; seller product/spec/image writes remain ownership-scoped. Renders all specs, supports up to 30, and retains submitted non-file values after errors. |
| `assets/js/product_management.js` | Vanilla Add/Remove Spec controls with accessible fields and a 30-row limit. Applies to both product editors. |
| `includes/activity_log.php` | Provides `log_activity($conn, $action, $target_type = null, $target_id = null)`. Prepared writes use session actor and validated REMOTE_ADDR; passwords, request bodies and API credentials are not recorded. |
| `admin/manage_products.php` | Admin-only entry point to view all sellers’ products and edit fields/specs/images/status. Product seller ownership is preserved. |
| `admin/activity.php` | Admin-only activity table with action/date filters and pagination. Shows actor, target, time and IP for manual investigation; it is not an automated fraud classifier. |

All new styles are in `assets/css/style.css`. The SQL file contains schema/seed data; the PDF contains the SRS. Python files under `tests/` are optional verification tools, not application dependencies.

## What Is Complete

- FR-01–04: registration, approval-gated seller access, email login, profiles/addresses, session expiry and refreshed role/stat us guards. Only customers can buy or review.
- FR-05–06/09: category hierarchy, price/brand/specification filters, product details, and catalog cards with two specs, unflagged review averages and customer-only cart controls.
- FR-11–20: owned carts, live stock checks, inline/saved-address checkout, atomic inventory/order writes, history, allowed-state cancellation/restocking and delivered-purchase reviews.
- FR-21–27: seller listings/uploads/specs and sales summaries; admin product override, category management, seller approval/suspension, platform orders and moderation.
- UC-04: new orders/status transitions have actor/time histories; seller transitions may include tracking notes. Earlier orders have no fabricated past events.
- Activity review: login, logout, failed_login, order_placed, order_cancelled, product_created, product_deactivated, user_suspended and review_flagged events are recorded and filterable.
- Groq conversations, bilingual/voice input, local keyword fallback and basic view/popularity recommendations exist; stricter SRS gaps remain below.

## What Is Not Yet Built

The ten requested commerce/admin compliance fixes are complete. The following work remains outside that fix list; chatbot behavior was explicitly excluded from this update:

- FR-07/08/28–30 and UC-01: meaningful Groq relevance scores, confidence assessment/low-confidence fallback, category-context enforcement, caller-selectable maximum results, AI-mode labeling and refinement guidance. Header search remains keyword-only.
- NFR-02: one five-second end-to-end AI deadline including catalog loading and fallback. Existing budgets allow 3.5 seconds for Groq plus 2 seconds for fallback, with an 8-second PHP limit.
- FR-10/UC-05: purchase-history and anonymous-session personalization, personalized detail recommendations, and recommendations on search results. Home recommendations remain a grid; detail alternatives use category popularity rather than true co-view sessions.
- NFR-10: latest-two-version desktop verification across Chrome, Firefox, Edge and Safari. This update tested the specification editor in installed Chrome only.
- Remaining conceptual screen details include cart/product-list thumbnails, cart shipping estimate, full parent breadcrumbs, secondary carousels, delivery estimates and seller sidebar layout.
- Search/category pages cap results at 200 without pagination. Dual-role accounts are not implemented; purchasing/reviews are customer-only.
- Real payments, carrier integrations and native apps remain outside prototype scope. Activity logs support manual investigation, not automated suspicious-activity classification.

## Known Issues and Design Decisions

- **Applied repairs:** files were relocated, URLs changed to `/Project/`, both missing category columns were added to the live database and dump, and empty order statuses were normalized to `pending` (including seeded order 4). Existing store passwords were preserved.
- **Shipping:** ৳60 below ৳5,000, free at or above ৳5,000, no tax. Checkout calculates line totals in integer cents before writing DECIMAL values. Payment remains simulated.
- **Order states:** `processing` corresponds approximately to SRS `Confirmed`. One status covers a multi-seller order; sellers see only their own line items but an authorized transition changes the shared order status.
- **Cancellation:** customers cancel pending or processing (Confirmed) orders only; sellers cannot reopen cancelled orders or move backward. Admins can update statuses, but cancellation is limited to pending/processing for every actor. Reopening cancelled orders reserves stock again and fails if products are inactive or stock is insufficient.
- **History:** deactivation preserves order product references and order items retain unit-price/subtotal snapshots. Product names and shipping addresses remain live references; editing an address changes its presentation in prior orders, and referenced addresses cannot be deleted.
- **Revenue:** noncancelled order value includes pending orders, not verified collected payments. Admin totals include shipping; seller totals contain their own line items only.
- **Categories:** public retrieval respects both child and parent activation; server validation enforces two levels and leaf products for application writes.
- **Reviews:** one review per user/product, only after delivered purchase; flagged rows remain stored but disappear from public lists/averages. Customer review editing is not implemented.
- **Assistant:** Groq receives active catalog names, prices, brands, categories, stock and structured specs plus conversation text. The requested configured model is `llama3-70b-8192`, with automatic retired-model retry to `qwen/qwen3.6-27b`. The local parser is only the provider-failure fallback. `used_ai=1` records an assistant attempt, not proof of a successful provider reply.
- **Search:** limits are six assistant results, 200 keyword/category cards and 255 query characters. MariaDB `max_statement_time` bounds SQL; this setting is specific to the XAMPP MariaDB target rather than Oracle MySQL portability.
- **Recommendations:** “Customers Also Viewed” means popularity in the same category over 30 days, not tracked co-view sessions. Personal home results are distinct recent views, and guests use seven-day aggregate trends.
- **Sessions:** entry points start sessions before output; `db.php` checks expiry and refreshed account status before mutation handlers, and the header retains its timeout check. Commerce/admin writes require CSRF-protected POST; the public search-only endpoint does not trust posted identity.
- **Conventions:** all application SQL uses prepared statements, including fixed queries. Dynamic SQL contains generated placeholders or allowlisted structural clauses; `h()` uses `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`. CSS is hyphenated lowercase, money uses ৳ and displayed dates use `d M Y`.
- **Dependencies:** PHP needs MySQLi/mysqlnd, mbstring, cURL with CA certificates, and fileinfo for image validation. Voice recognition depends on browser support/permission and may use the browser vendor’s speech service. Google Fonts and remote images depend on external hosts; local fallbacks exist.

### JSON endpoint contract

POST `/Project/ai_search.php` with form-encoded `query`; `action=init` instead loads the catalog server-side and restores the session’s last six messages. Identity/history are session-derived. Queries are limited to 255 characters; optional `cat` currently affects local fallback only.

Successful messages include `success`, `message`, `results`, `result_count`, `used_ai`, `confidence`, `fallback` and `history`. Products include `product_id`, `name`, numeric `price`, `brand`, `stock_qty`, `category`, `image_url` and `relevance_score`. Valid Groq replies currently receive score 1.0 and high confidence; these are not calibrated measures. Detected category/price fields are provided by local fallback, not necessarily by Groq replies.

PHP sends catalog/context to Groq over HTTPS, requesting short catalog-grounded replies in the user’s language. Groq returns text and product IDs; PHP validates IDs and uses database card values. The API key stays in `db.php`; API/format failures invoke local search and the UI shows a non-blocking notice.

Malformed methods/queries return HTTP 405/422 JSON errors. Browser message requests abort after 9.5 seconds. Catalog retrieval precedes the 3.5-second Groq budget, fallback receives another 2 seconds, and PHP has an 8-second limit; the overall SRS performance bound remains incomplete.

## How To Run

1. Start Apache and MySQL in XAMPP. The dump was generated on PHP 8.2.12/MariaDB 10.4.32; enable MySQLi/mysqlnd and mbstring.
2. Keep the project in `C:\xampp\htdocs\Project` with the folder structure shown above.
3. For a fresh installation, create/select `projukti_mart` using `utf8mb4_general_ci` in http://localhost/phpmyadmin/ and import `projukti_mart.sql`. It includes 15 tables, the compliance additions, foreign keys and the FULLTEXT index. Do not reimport over an existing store.
4. For an existing store, back up the database and run `migrations/001_compliance.sql` with `projukti_mart` selected. It preserves current accounts/passwords, adds the pending-approval enum and update timestamps, and creates history/activity tables. It is rerunnable on XAMPP MariaDB. The live database in this workspace has already received it. Very old installations also need `categories.description` and `categories.is_active`, present in the supplied dump.

5. Configure `db.php` if necessary: defaults are localhost, root, empty password and `projukti_mart`. Optional environment overrides are `PM_DB_HOST`, `PM_DB_USER`, `PM_DB_PASS` and `PM_DB_NAME`; the verification suite uses the database override for isolation.
6. Open **http://localhost/Project/**. Customers register and shop immediately and can add a first address inline at checkout. New sellers must wait for administrator approval under Manage Users before logging in.
7. Configure a valid `GROQ_API_KEY` in `db.php`, PHP cURL/CA certificates, and outbound HTTPS access to `api.groq.com` for assistant replies. Core commerce and keyword search work during provider outages. Ensure `images/` is writable and PHP `upload_max_filesize`/`post_max_size` accommodate the intended upload (5MB per image, ten images maximum).

### Admin setup

The dump contains active admin ID 1, username `admin`, email **admin@projuktimart.com**. Its bcrypt hash is preserved; no verified plaintext password is supplied, so do not assume a default password.

For a known local admin password, register a normal account, edit that specific account's role to `admin` and status to `active` in phpMyAdmin, then log out and back in. Alternatively copy the generated hash from a temporary account with your chosen password into the seeded administrator's password field and use that password with the seeded email; never store a plaintext password.

### Verification

Verified on 8 September 2026 after the compliance changes:

- All 34 PHP files passed `php -l`; new product-editor JavaScript passed `node --check assets/js/product_management.js`.
- `python tests/compliance.py` passed **52 assertions** covering approval/CSRF, role restrictions, admin overrides, eight-spec preservation/validation retention, card specs/ratings, inline checkout rollback, timestamps, history/notes, cancellation safeguards, all nine activity events, filters and migration reruns.
- `python tests/compliance.py --browser` passed **53 assertions**, including installed headless Chrome checks of actual Add/Remove Spec controls, validation retention and database persistence. Browser mode additionally requires Python `websocket-client` and installed Chrome.
- Existing `tests/verify.py` passed **78 regression assertions** with `curl_init` disabled in its temporary PHP server to force the local AI-outage path. The 5,000-product keyword-search test remained below two seconds with enriched cards. Maximum measured local fallback response was 0.035 seconds; this is not Groq latency.
- Existing regression/browser scripts retain pre-Groq assumptions. An unmodified live-Groq run is not certified by that offline result. Chatbot code and existing chatbot tests were preserved.
- Both integration suites use unique `projukti_mart_verify_<random>` databases and temporary PHP servers, modify only fixture accounts/orders, and remove their test databases afterward. They require access to XAMPP PHP/MySQL and local session storage. The new compliance suite never calls Groq.
- The live migration is applied and the database contains 15 tables. Existing store passwords were not reset. SHA-256 checks confirm `ai_search.php`, `assets/js/chatbot.js` and `includes/footer.php` are unchanged.
- These results do not certify production load, all concurrency schedules, or the latest two versions of every SRS browser.
