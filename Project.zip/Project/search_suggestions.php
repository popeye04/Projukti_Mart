<?php
@session_start();
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
ini_set('display_errors', '0');

try {
    require_once __DIR__ . '/db.php';
    $query = mb_substr(input_text($_GET, 'q'), 0, 80);
    if (mb_strlen($query) < 1) {
        echo json_encode(['products' => []]);
        exit;
    }

    // Match the beginning of a product name so short, single-word input is useful.
    // Escape LIKE metacharacters so a typed % or _ remains ordinary text.
    $prefix = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $query) . '%';
    $rows = db_run(
        "SELECT p.product_id, p.name, p.price, c.category_name
         FROM products p
         JOIN categories c ON c.category_id = p.category_id
         LEFT JOIN categories parent ON parent.category_id = c.parent_category_id
         WHERE p.status = 'active' AND c.is_active = 1
           AND (parent.category_id IS NULL OR parent.is_active = 1)
           AND p.name LIKE ? ESCAPE '\\\\'
         ORDER BY p.name ASC, p.product_id DESC LIMIT 6",
        's', [$prefix]
    )->get_result()->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['products' => $rows], JSON_UNESCAPED_UNICODE);
} catch (Throwable $exception) {
    http_response_code(503);
    echo json_encode(['products' => []]);
}
