<?php
session_start();
require_once 'db.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['logout'])) {
    if (isset($_SESSION['user_id'])) {
        log_activity($conn, 'logout', 'user', (int) $_SESSION['user_id']);
    }
    session_unset();
    session_destroy();
    header('Location: /Project/login.php');
    exit();
}

$page_title = 'Logout';
include 'includes/header.php';
echo '<div class="page-heading"><p class="page-eyebrow">Session</p><h1>Logout</h1><p class="page-intro">Confirm logout to sign out securely.</p></div><div class="auth-wrapper"><div class="auth-card"><form method="POST">' . csrf_field() . '<button type="submit" name="logout" class="btn-filter">Confirm Logout</button></form></div></div>';
include 'includes/footer.php';
exit;
?>
