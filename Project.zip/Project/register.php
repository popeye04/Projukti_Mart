<?php
session_start();
require_once 'db.php';

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
$redirect = safe_redirect($_POST['redirect'] ?? $_GET['redirect'] ?? 'index.php');
if (isset($_POST['register'])) {
    $username = input_text($_POST, 'username');
    $full_name = input_text($_POST, 'full_name');
    $email = input_text($_POST, 'email');
    $phone = input_text($_POST, 'phone');
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';
    $confirm = is_string($_POST['confirm_password'] ?? null) ? $_POST['confirm_password'] : '';
    $role = input_text($_POST, 'role') === 'seller' ? 'seller' : 'customer';
    if ($username === '' || strlen($username) > 50 || $full_name === '' || strlen($full_name) > 100 || strlen($email) > 100 || !email_allowed_for_role($email, $role) || strlen($phone) > 20) {
        $error = $role === 'customer'
            ? 'Customer accounts require a valid @gmail.com email, username, full name, and phone.'
            : 'Enter a valid email, username, full name, and phone within the field limits.';
    } elseif ($password !== $confirm || strlen($password) < 6 || strlen($password) > 72) {
        $error = 'Passwords must match and contain 6 to 72 bytes.';
    } else {
        try {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $status = $role === 'seller' ? 'pending_approval' : 'active';
            $created = db_run('INSERT INTO users (username, password, role, full_name, email, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?)', 'sssssss', [$username, $hashed, $role, $full_name, $email, $phone, $status]);
            if ($role === 'seller') {
                $_SESSION['approval_notice'] = 'Your seller account is awaiting admin approval';
                header('Location: login.php'); exit;
            }
            session_regenerate_id(true);
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['user_id'] = $created->insert_id;
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $role;
            $_SESSION['last_activity'] = time();
            header('Location: ' . $redirect); exit;
        } catch (mysqli_sql_exception $exception) {
            $error = $exception->getCode() === 1062 ? 'That username or email is already registered.' : 'Registration is unavailable. Please try again.';
        }
    }
}

$page_title = 'Register';
include 'includes/header.php';
?>

<div class="auth-wrapper">
    <div class="auth-card">
        <p class="page-eyebrow">A better connection</p>
        <h1>Create an Account</h1>
        <p class="auth-caption">Discover your next favourite piece of technology.</p>
        <?php if ($error): ?><p class="stock-warning-box"><?php echo h($error); ?></p><?php endif; ?>

        <form method="POST"><?= csrf_field() ?>
            <input type="hidden" name="redirect" value="<?php echo h($redirect); ?>">

            <div class="filter-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo isset($_POST['username']) ? h($_POST['username']) : ''; ?>" required>
            </div>
            <div class="filter-group">
                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" required value="<?php echo isset($_POST['full_name']) ? h($_POST['full_name']) : ''; ?>">
            </div>
            <div class="filter-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? h($_POST['email']) : ''; ?>" required>
            </div>
            <div class="filter-group">
                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" value="<?php echo isset($_POST['phone']) ? h($_POST['phone']) : ''; ?>">
            </div>
            <div class="filter-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="filter-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>

            <div class="filter-group">
                <label>I want to</label>
                <div class="role-options">
                    <label class="role-option">
                        <input type="radio" name="role" value="customer" <?php echo (!isset($_POST['role']) || $_POST['role'] === 'customer') ? 'checked' : ''; ?>>
                        <span>Shop as a Customer</span>
                    </label>
                    <label class="role-option">
                        <input type="radio" name="role" value="seller" <?php echo (isset($_POST['role']) && $_POST['role'] === 'seller') ? 'checked' : ''; ?>>
                        <span>Sell as a Seller</span>
                    </label>
                </div>
            </div>

            <button type="submit" name="register" class="btn-hero auth-submit">Create Account</button>
        </form>

        <p class="auth-switch">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
