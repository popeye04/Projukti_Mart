<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?redirect=" . urlencode("profile.php"));
    exit();
}
if (($_SESSION['role'] ?? '') !== 'customer') {
    $_SESSION['store_error'] = 'Profile addresses are available to customer accounts only.';
    header('Location: ' . role_home_path((string) $_SESSION['role']));
    exit();
}

$user_id = intval($_SESSION['user_id']);
$message = '';

// Serialize address defaults per user.
try {
    if (isset($_POST['update_profile'])) {
        $full_name = input_text($_POST, 'full_name');
        $email = input_text($_POST, 'email');
        $phone = input_text($_POST, 'phone');
        $role = (string) ($_SESSION['role'] ?? '');
        if ($full_name === '' || strlen($full_name) > 100 || strlen($phone) > 20 || strlen($email) > 100 || !email_allowed_for_role($email, $role)) {
            $email_message = $role === 'customer' ? 'Customers must use a valid @gmail.com email.' : ($role === 'admin' ? 'The admin account must use admin@projuktimart.com.' : 'Enter a valid email address.');
            throw new InvalidArgumentException($email_message . ' Check your name and phone too.');
        }
        db_run('UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?', 'sssi', [$full_name, $email, $phone, $user_id]);
        $message = 'Profile updated.';
    }
    if (isset($_POST['add_address']) || isset($_POST['edit_address']) || isset($_POST['remove_address']) || isset($_POST['set_default'])) {
        $conn->begin_transaction();
        db_run('SELECT user_id FROM users WHERE user_id = ? FOR UPDATE', 'i', [$user_id]);
        $address_id = (int) ($_POST['address_id'] ?? 0);
        if (!isset($_POST['add_address']) && !db_run('SELECT address_id FROM addresses WHERE address_id = ? AND user_id = ? FOR UPDATE', 'ii', [$address_id, $user_id])->get_result()->fetch_assoc()) {
            throw new InvalidArgumentException('Address not found.');
        }
        if (isset($_POST['add_address']) || isset($_POST['edit_address'])) {
            $values = [];
            foreach (['line1' => 150, 'line2' => 150, 'city' => 50, 'postal_code' => 20, 'country' => 50] as $key => $limit) {
                $value = input_text($_POST, $key);
                if (strlen($value) > $limit || (in_array($key, ['line1', 'city', 'country'], true) && $value === '')) {
                    throw new InvalidArgumentException('Enter a complete address within the field limits.');
                }
                $values[] = $value;
            }
            if (isset($_POST['add_address'])) {
                db_run('INSERT INTO addresses (user_id, line1, line2, city, postal_code, country) VALUES (?, ?, ?, ?, ?, ?)', 'isssss', array_merge([$user_id], $values));
            } else {
                db_run('UPDATE addresses SET line1 = ?, line2 = ?, city = ?, postal_code = ?, country = ? WHERE address_id = ? AND user_id = ?', 'sssssii', array_merge($values, [$address_id, $user_id]));
            }
        } elseif (isset($_POST['remove_address'])) {
            if (db_run('SELECT order_id FROM orders WHERE address_id = ? LIMIT 1', 'i', [$address_id])->get_result()->fetch_assoc()) {
                throw new InvalidArgumentException('This address is used by an order and cannot be deleted. Add a new address instead.');
            }
            db_run('DELETE FROM addresses WHERE address_id = ? AND user_id = ?', 'ii', [$address_id, $user_id]);
        } else {
            db_run('UPDATE addresses SET is_default = (address_id = ?) WHERE user_id = ?', 'ii', [$address_id, $user_id]);
        }
        $default_address = db_run('SELECT address_id FROM addresses WHERE user_id = ? ORDER BY is_default DESC, address_id ASC LIMIT 1', 'i', [$user_id])->get_result()->fetch_assoc();
        if ($default_address) {
            db_run('UPDATE addresses SET is_default = (address_id = ?) WHERE user_id = ?', 'ii', [$default_address['address_id'], $user_id]);
        }
        $conn->commit();
        header('Location: profile.php');
        exit;
    }
} catch (Throwable $exception) {
    $conn->rollback();
    $message = $exception instanceof InvalidArgumentException ? $exception->getMessage() : 'Unable to save. Check whether this email is already registered.';
}

$page_title = 'My Profile';
include 'includes/header.php';

$user_stmt = $conn->prepare("SELECT username, full_name, email, phone, role FROM users WHERE user_id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();

$addr_stmt = $conn->prepare("SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, address_id DESC");
$addr_stmt->bind_param("i", $user_id);
$addr_stmt->execute();
$addresses = $addr_stmt->get_result();

// If an edit link was clicked, load that address into the form
$editing_address = null;
if (isset($_GET['edit_address'])) {
    $edit_id = intval($_GET['edit_address']);
    $edit_stmt = $conn->prepare("SELECT * FROM addresses WHERE address_id = ? AND user_id = ?");
    $edit_stmt->bind_param("ii", $edit_id, $user_id);
    $edit_stmt->execute();
    $editing_address = $edit_stmt->get_result()->fetch_assoc();
}
?>

<div class="page-heading">
    <p class="page-eyebrow">Your account, your way</p>
    <h1>My Profile</h1>
    <p class="page-intro">Keep your details and delivery addresses up to date.</p>
</div>

<?php if ($message): ?><p class="cart-message"><?php echo h($message); ?></p><?php endif; ?>

<div class="profile-layout">
    <section class="profile-card">
        <h2>Personal Information</h2>
        <form method="POST"><?= csrf_field() ?>
            <div class="filter-group">
                <label>Username</label>
                <input type="text" value="<?php echo h($user['username']); ?>" disabled>
            </div>
            <div class="filter-group">
                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" value="<?php echo h($user['full_name'] ?? ''); ?>">
            </div>
            <div class="filter-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo h($user['email'] ?? ''); ?>" required>
            </div>
            <div class="filter-group">
                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" value="<?php echo h($user['phone'] ?? ''); ?>">
            </div>
            <button type="submit" name="update_profile" class="btn-filter">Save Changes</button>
        </form>
    </section>

    <section class="profile-card">
        <h2><?php echo $editing_address ? 'Edit Address' : 'Add New Address'; ?></h2>
        <form method="POST"><?= csrf_field() ?>
            <?php if ($editing_address): ?>
                <input type="hidden" name="address_id" value="<?php echo $editing_address['address_id']; ?>">
            <?php endif; ?>
            <div class="filter-group">
                <label for="line1">Address Line 1</label>
                <input type="text" id="line1" name="line1" value="<?php echo h($editing_address['line1'] ?? ''); ?>" required>
            </div>
            <div class="filter-group">
                <label for="line2">Address Line 2</label>
                <input type="text" id="line2" name="line2" value="<?php echo h($editing_address['line2'] ?? ''); ?>">
            </div>
            <div class="filter-group">
                <label for="city">City</label>
                <input type="text" id="city" name="city" value="<?php echo h($editing_address['city'] ?? ''); ?>" required>
            </div>
            <div class="filter-group">
                <label for="postal_code">Postal Code</label>
                <input type="text" id="postal_code" name="postal_code" value="<?php echo h($editing_address['postal_code'] ?? ''); ?>">
            </div>
            <div class="filter-group">
                <label for="country">Country</label>
                <input type="text" id="country" name="country" value="<?php echo h($editing_address['country'] ?? 'Bangladesh'); ?>" required>
            </div>
            <button type="submit" name="<?php echo $editing_address ? 'edit_address' : 'add_address'; ?>" class="btn-filter">
                <?php echo $editing_address ? 'Update Address' : 'Add Address'; ?>
            </button>
        </form>
    </section>
</div>

<section class="address-list">
    <h2>Saved Addresses</h2>
    <?php if ($addresses->num_rows === 0): ?>
        <p class="empty-state">No saved addresses yet — add one above.</p>
    <?php else: ?>
        <?php while ($addr = $addresses->fetch_assoc()): ?>
        <div class="address-card">
            <p>
                <?php echo h($addr['line1']); ?><?php echo $addr['line2'] ? ', ' . h($addr['line2']) : ''; ?><br>
                <?php echo h($addr['city']); ?><?php echo $addr['postal_code'] ? ', ' . h($addr['postal_code']) : ''; ?><br>
                <?php echo h($addr['country']); ?>
            </p>
            <?php if ($addr['is_default']): ?>
                <span class="default-badge">Default</span>
            <?php endif; ?>
            <div class="address-actions">
                <a href="profile.php?edit_address=<?php echo $addr['address_id']; ?>">Edit</a>
                <?php if (!$addr['is_default']): ?>
                    <form method="POST" class="inline-form"><?= csrf_field() ?><input type="hidden" name="address_id" value="<?= (int) $addr['address_id'] ?>"><button name="set_default" class="btn-filter">Set as Default</button></form>
                <?php endif; ?>
                <form method="POST" class="inline-form"><?= csrf_field() ?><input type="hidden" name="address_id" value="<?= (int) $addr['address_id'] ?>"><button name="remove_address" class="remove-link">Delete</button></form>
            </div>
        </div>
        <?php endwhile; ?>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
